Folder 'working' to wersje robocze kodów.

Wersje kodów rzeczywiście wykorzystywane do ostatecznych odpowiedzi znajdują się w folderze 'final_files'.

W folderze głównym najważniejszy plik to 'run_analysis.py', który uruchamia wszystkie inne pliki.

Plik 'answers', trzy pliki 'task2' i plik 'task3' są generowane jako odpowiedzi do zadania.

Plik 'answers_interpretation' zawiera tekstowe podsumowanie zadania.

Plik 'output.pstats' zawiera wynik działania profilera. Można go otworzyć po zainstalowaniu biblioteki 'snakeviz' za pomocą komendy:

snakeviz output.pstats
